import { createClient } from '@supabase/supabase-js'
import { streamText } from 'ai'
import { openai } from '@ai-sdk/openai'
import { getMockResponse } from '@/lib/email-studio-mocks'

// ================================================
// EMAIL STUDIO v2.2 – ACTION-SPECIFIK + DEMO-LÄGE
// ================================================
// Nyheter jämfört med v2.1:
// 1. ACTION_INSTRUCTIONS: varje knapp injicerar en egen, riktad
//    instruktion i prompten → garanterat distinkta beteenden.
// 2. Demo-läge: om EMAIL_STUDIO_MOCK=true eller OPENAI_API_KEY
//    saknas returneras automatiserade exempelsvar (streamade),
//    så att knapparna alltid går att testa på localhost.
// 3. Validering av action mot tillåten lista.
// 4. Supabase är valfritt i demo-läge (kraschar inte utan env).
// ================================================

const ALLOWED_ACTIONS = [
  'Kortare',
  'Skriv om',
  'Tydligare CTA',
  'Mer personlig',
  'Förbättra',
  'A/B-varianter',
  'Uppföljning',
  'Analysera',
] as const

type EmailAction = (typeof ALLOWED_ACTIONS)[number]

// Distinkt, riktad instruktion per action – injiceras i user-prompten
// utöver system-prompten, så att modellen inte kan ge generiska svar.
const ACTION_INSTRUCTIONS: Record<EmailAction, string> = {
  'Kortare': `UPPGIFT: Gör mailet ruthlessly short (cold-email/SKILL.md).
- Ta bort VARJE mening som inte direkt driver mot ett svar.
- Mål: 40-60% kortare än originalet. Räkna orden.
- Behåll kärnbudskap + trigger + CTA. Ta bort självpresentation och fluff.
- Ändra INTE vinkeln eller tonen i övrigt – bara komprimera.`,

  'Skriv om': `UPPGIFT: Skriv om hela mailet med NY struktur eller ton (cold-email/SKILL.md).
- Välj en tydlig förändring: t.ex. problem-först-struktur, fråge-öppning, eller peer-to-peer-ton.
- Nämn i förklaringen exakt vilken strukturell/tonal förändring du valde och varför.
- Behåll samma trigger och erbjudande – det är formen som ska bytas, inte innehållet.`,

  'Tydligare CTA': `UPPGIFT: Fokusera nästan uteslutande på CTA:n.
- Gör CTA:n starkare, mer specifik och lätt att svara på: konkreta tider, "svara ja", eller ett-ords-svar.
- EN låg-friktion CTA per mail (cold-email/SKILL.md). Ta bort konkurrerande CTA:er.
- Resten av mailet får bara justeras minimalt för att stödja CTA:n.
- Markera den nya CTA:n i fetstil i "Ny version".`,

  'Mer personlig': `UPPGIFT: Fördjupa personaliseringen med Personalization Sub-Agent-logik.
- Använd "Context / Signaler" för att lägga till 1-2 MYCKET specifika, icke-uppenbara detaljer.
- Varje detalj MÅSTE kopplas till mottagarens problem – aldrig löst smicker.
- Om context saknas eller är för tunn: be om mer context FÖRST istället för att hitta på.
- Ändra så lite som möjligt utöver personaliseringen.`,

  'Förbättra': `UPPGIFT: Helhetsoptimering av subject + öppning + body + CTA (copywriting + cold-email/SKILL.md).
- Öppning: led med mottagarens situation, aldrig "jag heter".
- Body: en tanke per stycke, konkreta utfall istället för vaga procentsatser.
- CTA: låg friktion, specifik.
- Inkludera en ny ämnesrad överst i "Ny version" (märkt "Ämne:").`,

  'A/B-varianter': `UPPGIFT: Generera 2-3 distinkta versioner (ab-testing/SKILL.md).
- Märk dem "Version A", "Version B", "Version C" med vinkel-etikett (t.ex. pain-driven / opportunity-driven / social proof).
- Isolera EN variabel (vinkeln) – håll längd och CTA-friktion så konstant som möjligt.
- Ge en ämnesrad per version i "Förslag på ämnesrad".
- Nämn i tipset hur testet ska mätas (svarsfrekvens, minsta urval).`,

  'Uppföljning': `UPPGIFT: Skapa en naturlig uppföljning på draften (cold-email/SKILL.md follow-up-principer).
- FÖRBJUDET: "ville bara kolla läget", "bumping this", ren repetition av pitchen.
- Uppföljningen MÅSTE addera nytt värde: en ny insikt, en konkret resurs, eller ett nytt perspektiv.
- Kort – max hälften av originalets längd.
- Ge gärna en enkel utväg (t.ex. "säg till om tajmingen är fel").`,

  'Analysera': `UPPGIFT: Analysera – skriv INTE om mailet.
- Ge ärliga betyg 1-10 på: Klarhet, Personalisering, CTA-styrka, Spam-risk (var för sig).
- Ge 3-4 konkreta, prioriterade förbättringar bundna till marketingskills-principer.
- I "Ny version"-fältet: skriv "(Analys – ingen omskrivning. Kör 'Förbättra' för en ny version.)" följt av betygen.
- Avsluta med ett totalbetyg + vilken enskild åtgärd som ger störst effekt.`,
}

const EMAIL_STUDIO_SYSTEM_PROMPT = `# Snipe-Leads Email Studio v2.2

Du är Email Studio – den autonoma AI-assistenten i Snipe-Leads (Snipra).

**Obrytbar grundregel:**
Du använder ALLTID ramverken från https://github.com/coreyhaines31/marketingskills (cold-email/SKILL.md, copywriting/SKILL.md, ab-testing/SKILL.md, emails/SKILL.md).

**VIKTIGT: Du får alltid ett "action"-fält och en ACTION-SPECIFIK UPPGIFT i prompten.**
Uppgiften beskriver exakt vad som ska förändras. Följ den till punkt och pricka – gör INTE en generisk allmänförbättring om uppgiften är avgränsad (t.ex. "Tydligare CTA" ska inte skriva om hela mailet).

**Output-format (EXAKT detta – ingen avvikelse):**

**Ursprunglig version:**
**Ny version:**
**Förklaring av förändringarna:** (kort + referens till marketingskills)
**Förslag på ämnesrad:** (2–3 stycken)
**Konfidens / Tips:** (valfritt)

**Ton & stil:** Modern, rak, vänlig, främst svenska. Skriv som en smart och kompetent kollega. Aldrig spammigt, aldrig "I hope this email finds you well".

**Kvalitetskontroll innan du svarar:**
- Låter det som en människa skrev det?
- Är personaliseringen verklig och relevant?
- Finns det en tydlig, låg-friktion CTA?
- Skulle du själv svara på mailet om du var mottagaren?

Om context saknas och det behövs för "Mer personlig" → be om det först.

Du är hjälpsam, snabb och proaktiv.`

// ================================================
// Supabase (valfritt – kraschar inte i demo-läge)
// ================================================
function getSupabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!url || !key) return null
  return createClient(url, key)
}

const isMockMode = () =>
  process.env.EMAIL_STUDIO_MOCK === 'true' || !process.env.OPENAI_API_KEY

// Streamar en färdig textsträng som en vanlig text-stream,
// så att frontend kan behandla demo-svar och riktiga svar identiskt.
function streamMock(text: string): Response {
  const encoder = new TextEncoder()
  const chunks = text.match(/[\s\S]{1,48}/g) ?? [text]
  const stream = new ReadableStream({
    async start(controller) {
      for (const chunk of chunks) {
        controller.enqueue(encoder.encode(chunk))
        await new Promise((r) => setTimeout(r, 12)) // simulerad streaming
      }
      controller.close()
    },
  })
  return new Response(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'X-Email-Studio-Mode': 'mock',
    },
  })
}

// ================================================
// API ROUTE
// ================================================
export async function POST(req: Request) {
  try {
    const { action, draft, subject, context, userId, mockVariant } = await req.json()

    if (!action || !draft) {
      return new Response(JSON.stringify({ error: 'action och draft krävs' }), { status: 400 })
    }
    if (!ALLOWED_ACTIONS.includes(action)) {
      return new Response(
        JSON.stringify({ error: `Okänd action. Tillåtna: ${ALLOWED_ACTIONS.join(', ')}` }),
        { status: 400 }
      )
    }

    const supabase = getSupabase()

    // Spara i historik (blockera aldrig svaret om det misslyckas)
    if (supabase && userId) {
      supabase
        .from('email_history')
        .insert({
          user_id: userId,
          action,
          original: draft,
          lead_context: context || '',
          created_at: new Date().toISOString(),
        })
        .then(({ error }) => {
          if (error) console.warn('[Email Studio] history insert failed:', error.message)
        })
    }

    // ---------- DEMO-LÄGE: automatiserade exempelsvar ----------
    if (isMockMode()) {
      const text = getMockResponse(action, draft, Number(mockVariant) || 0)
      return streamMock(text)
    }

    // ---------- SKARPT LÄGE: riktig modell ----------
    let prefs: Record<string, unknown> = {}
    if (supabase && userId) {
      const { data } = await supabase
        .from('user_preferences')
        .select('*')
        .eq('user_id', userId)
        .single()
      if (data) prefs = data
    }

    const prompt = `
Användarpreferenser: ${JSON.stringify(prefs)}

=== ACTION: ${action} ===
${ACTION_INSTRUCTIONS[action as EmailAction]}

${subject ? `Befintlig subject: ${subject}` : ''}
Draft:
${draft}

Context / Signaler från lead: ${context || 'Ingen extra context'}

Följ EXAKT output-formatet i system-prompten och den action-specifika uppgiften ovan.
`

    const result = await streamText({
      model: openai('gpt-4o-mini'),
      system: EMAIL_STUDIO_SYSTEM_PROMPT,
      prompt,
      temperature: action === 'A/B-varianter' ? 0.9 : 0.7,
      maxTokens: 2200,
    })

    return result.toTextStreamResponse()
  } catch (error: any) {
    console.error('[Email Studio Error]', error)
    return new Response(JSON.stringify({ error: error.message }), { status: 500 })
  }
}
