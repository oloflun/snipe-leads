# Email Studio – Snipe-Leads

Komplett implementation av Email Studio enligt `Email-Studio-Improved-Prompt-for-Fable5.md`, punkt 1 och 2, med **automatiserade exempelsvar** så att alla funktionsknappar kan testas på localhost – med eller utan API-nyckel.

## Innehåll

| Fil | Vad |
|---|---|
| `app/api/email-studio/route.ts` | API-route (Vercel AI SDK, streaming, Supabase, action-specifik logik, demo-läge) |
| `components/EmailStudio.tsx` | React-komponent: 8 knappar, streaming, parsat resultat, "Använd denna version", ämnesrads-chips, förhandsvisning |
| `app/email-studio/page.tsx` | Sida som monterar komponenten på `/email-studio` |
| `lib/email-studio-mocks.ts` | Automatiserade exempelsvar: 2 varianter per action × 8 actions |
| `supabase/email_studio.sql` | Tabellerna `user_preferences` + `email_history` med RLS |
| `demo/index.html` + `demo/mocks.js` | Fristående demo – testa knapparna direkt utan Next.js |

## Snabbast: testa funktionsknapparna direkt (fristående demo)

Ingen installation, inga nycklar:

```bash
cd demo
python -m http.server 3000
# eller: npx serve .
```

Öppna **http://localhost:3000**. Klicka "Fyll i exempel-draft", tryck på en funktionsknapp, och använd **"Nästa exempel ↻"** för att växla mellan de automatiserade exempelsvaren per knapp. "Använd denna version" skriver tillbaka den nya versionen till draften (och lyfter ut "Ämne:" till subject-fältet om det finns).

## Installera i Snipe-Leads-projektet (`C:\Users\sebbe\snipe-leads`)

1. Kopiera in filerna på motsvarande platser:
   - `app/api/email-studio/route.ts`
   - `app/email-studio/page.tsx`
   - `components/EmailStudio.tsx`
   - `lib/email-studio-mocks.ts`

2. Installera beroenden (om de saknas):
   ```bash
   npm i ai @ai-sdk/openai @supabase/supabase-js
   ```

3. Kör SQL:en i `supabase/email_studio.sql` i Supabase SQL Editor.

4. Miljövariabler i `.env.local`:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=...
   SUPABASE_SERVICE_ROLE_KEY=...
   OPENAI_API_KEY=...            # utelämna för demo-läge
   EMAIL_STUDIO_MOCK=true        # tvinga demo-läge även med nyckel
   ```

5. Starta:
   ```bash
   npm run dev
   ```
   Öppna **http://localhost:3000/email-studio**.

## Demo-läge vs skarpt läge

- **Demo-läge** aktiveras automatiskt när `OPENAI_API_KEY` saknas, eller manuellt med `EMAIL_STUDIO_MOCK=true`. Routen streamar då de automatiserade exempelsvaren (samma format som skarpt läge) och sätter headern `X-Email-Studio-Mode: mock`. UI:t visar en demo-badge + knappen "Nästa exempel ↻".
- **Skarpt läge**: `streamText` med gpt-4o-mini, system-prompten v2.2 och en **riktad instruktion per action** (`ACTION_INSTRUCTIONS`) injicerad i prompten – det är detta som garanterar distinkta beteenden per knapp:
  - Kortare → 40–60% kortare, endast komprimering
  - Skriv om → ny struktur/ton, samma innehåll
  - Tydligare CTA → rör nästan bara CTA:n, fetstilad
  - Mer personlig → 1–2 icke-uppenbara detaljer från context, ber om context om den saknas
  - Förbättra → subject + öppning + body + CTA, ny ämnesrad märkt "Ämne:"
  - A/B-varianter → Version A/B/C med olika vinklar (högre temperatur)
  - Uppföljning → nytt värde, aldrig "bara kollar in"
  - Analysera → betyg 1–10 per dimension, ingen omskrivning

## Testa API:t med curl

```bash
curl -N http://localhost:3000/api/email-studio \
  -H "Content-Type: application/json" \
  -d '{
    "action": "Kortare",
    "draft": "Hej Anna, jag heter Sebastian och jobbar på Snipe-Leads...",
    "context": "Nytt kontor i Hyllie, rekryterar 3 säljare",
    "userId": "demo-user",
    "mockVariant": 0
  }'
```

Byt `action` mot valfri av: `Kortare`, `Skriv om`, `Tydligare CTA`, `Mer personlig`, `Förbättra`, `A/B-varianter`, `Uppföljning`, `Analysera`. I demo-läge växlar `mockVariant` (0, 1, 2 …) mellan exempelsvaren.

## Checklista mot specen

- [x] Route med streaming, system-prompt v2.x, `action`/`draft`/`context`/`userId`
- [x] Distinkt beteende per action (ACTION_INSTRUCTIONS + validering)
- [x] `user_preferences` hämtas, `email_history` sparas (icke-blockerande)
- [x] EmailStudio.tsx med 8 knappar, exakt output-format parsat, "Använd denna version", live-förhandsvisning
- [x] Automatiserade exempelsvar per knapp, växlingsbara
- [x] Testbar på localhost med UI, fristående demo och curl
