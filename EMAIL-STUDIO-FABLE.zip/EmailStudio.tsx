'use client'

import { useCallback, useMemo, useRef, useState } from 'react'

interface EmailStudioProps {
  userId: string
  initialDraft?: string
  initialContext?: string
}

interface StudioResult {
  raw: string
  action: string
  variant: number
  mode: 'mock' | 'live'
}

const ACTIONS = [
  { value: 'Kortare', hint: '40-60% kortare, behåller kärnan' },
  { value: 'Skriv om', hint: 'Ny struktur eller ton' },
  { value: 'Tydligare CTA', hint: 'Starkare, låg-friktion CTA' },
  { value: 'Mer personlig', hint: 'Väver in signaler från context' },
  { value: 'Förbättra', hint: 'Helhet: subject + öppning + body + CTA' },
  { value: 'A/B-varianter', hint: '2-3 versioner med olika vinklar' },
  { value: 'Uppföljning', hint: 'Follow-up som adderar nytt värde' },
  { value: 'Analysera', hint: 'Betyg 1-10 + konkreta förbättringar' },
] as const

// Parsar det obligatoriska output-formatet till sektioner
function parseResult(raw: string) {
  const grab = (label: string, next: string[]) => {
    const nextPattern = next.map((n) => `\\*\\*${n}`).join('|')
    const re = new RegExp(
      `\\*\\*${label}:?\\*\\*\\s*([\\s\\S]*?)(?=${nextPattern}|$)`,
      'i'
    )
    const m = raw.match(re)
    return m?.[1]?.trim() ?? ''
  }
  return {
    original: grab('Ursprunglig version', ['Ny version']),
    newVersion: grab('Ny version', ['Förklaring']),
    explanation: grab('Förklaring av förändringarna', ['Förslag på ämnesrad']),
    subjects: grab('Förslag på ämnesrad', ['Konfidens']),
    tips: grab('Konfidens \\/ Tips', []),
  }
}

function extractSubjectLines(subjectsBlock: string): string[] {
  return subjectsBlock
    .split('\n')
    .map((l) => l.replace(/^\s*(\d+[.)]|[-–•]|[ABC]:)\s*/i, '').trim())
    .filter((l) => l.length > 0 && l.length < 120)
    .slice(0, 3)
}

export default function EmailStudio({
  userId,
  initialDraft = '',
  initialContext = '',
}: EmailStudioProps) {
  const [draft, setDraft] = useState(initialDraft)
  const [context, setContext] = useState(initialContext)
  const [subject, setSubject] = useState('')
  const [result, setResult] = useState<StudioResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [activeAction, setActiveAction] = useState('')
  // Håller reda på vilket automatiserat exempel som visas per action,
  // så att "Nästa exempel" kan växla mellan svaren.
  const variantRef = useRef<Record<string, number>>({})

  const runAction = useCallback(
    async (action: string, variant?: number) => {
      if (!draft.trim()) {
        alert('Skriv eller klistra in en draft först')
        return
      }
      const v = variant ?? variantRef.current[action] ?? 0
      variantRef.current[action] = v

      setLoading(true)
      setActiveAction(action)
      setResult({ raw: '', action, variant: v, mode: 'live' })

      try {
        const res = await fetch('/api/email-studio', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action,
            draft,
            subject: subject || undefined,
            context: context || undefined,
            userId,
            mockVariant: v,
          }),
        })

        if (!res.ok) {
          const err = await res.json().catch(() => ({}))
          throw new Error(err.error || 'Något gick fel')
        }

        const mode = res.headers.get('X-Email-Studio-Mode') === 'mock' ? 'mock' : 'live'
        const reader = res.body?.getReader()
        const decoder = new TextDecoder()
        let fullText = ''

        if (reader) {
          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            fullText += decoder.decode(value, { stream: true })
            // Live-uppdatering medan svaret streamas in
            setResult({ raw: fullText, action, variant: v, mode })
          }
        }
        setResult({ raw: fullText, action, variant: v, mode })
      } catch (error: any) {
        console.error(error)
        alert(`Fel vid anrop till Email Studio: ${error.message}`)
        setResult(null)
      } finally {
        setLoading(false)
        setActiveAction('')
      }
    },
    [draft, subject, context, userId]
  )

  // Växlar till nästa automatiserade exempelsvar för samma action
  const nextExample = useCallback(() => {
    if (!result) return
    const next = (variantRef.current[result.action] ?? 0) + 1
    runAction(result.action, next)
  }, [result, runAction])

  const parsed = useMemo(() => (result ? parseResult(result.raw) : null), [result])
  const subjectSuggestions = useMemo(
    () => (parsed ? extractSubjectLines(parsed.subjects) : []),
    [parsed]
  )

  const applyVersion = () => {
    if (!parsed?.newVersion) {
      if (result?.raw) setDraft(result.raw)
      setResult(null)
      return
    }
    // Om "Ny version" inleds med "Ämne: ..." → lyft ut den till subject-fältet
    const lines = parsed.newVersion.split('\n')
    const subjLine = lines[0]?.match(/^\*{0,2}Ämne:\*{0,2}\s*(.+)$/i)
    if (subjLine) {
      setSubject(subjLine[1].trim())
      setDraft(lines.slice(1).join('\n').trim())
    } else {
      setDraft(parsed.newVersion)
    }
    setResult(null)
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div>
        <h2 className="text-2xl font-semibold mb-1">Email Studio</h2>
        <p className="text-gray-600 text-sm">
          Skriv en draft och använd funktionsknapparna. Varje knapp ger ett distinkt
          resultat baserat på cold-email-, copywriting- och A/B-testnings-principer.
        </p>
      </div>

      {/* Input */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Subject (valfritt)</label>
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="w-full border rounded-lg px-4 py-2"
            placeholder="T.ex. Hyllie-expansionen – hur hanterar ni lokala leverantörer?"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Draft-email</label>
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            className="w-full h-48 border rounded-lg px-4 py-3 font-mono text-sm"
            placeholder="Klistra in din draft här..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">
            Extra context / Signaler (LinkedIn, nyhet, expansion etc.)
          </label>
          <textarea
            value={context}
            onChange={(e) => setContext(e.target.value)}
            className="w-full h-24 border rounded-lg px-4 py-2 text-sm"
            placeholder="T.ex. Företaget har precis öppnat nytt kontor i Hyllie och rekryterar säljare"
          />
        </div>
      </div>

      {/* Funktionsknappar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {ACTIONS.map((a) => (
          <button
            key={a.value}
            onClick={() => runAction(a.value)}
            disabled={loading}
            title={a.hint}
            className={`px-4 py-3 rounded-xl border text-sm font-medium transition-all
              ${
                activeAction === a.value
                  ? 'bg-black text-white border-black'
                  : 'hover:bg-gray-50 border-gray-200'
              } disabled:opacity-60`}
          >
            {loading && activeAction === a.value ? 'Bearbetar…' : a.value}
          </button>
        ))}
      </div>

      {/* Live-förhandsvisning */}
      {(subject || draft) && !result && (
        <div className="border rounded-2xl p-5 bg-gray-50">
          <p className="text-xs uppercase tracking-wide text-gray-400 mb-2">
            Förhandsvisning
          </p>
          {subject && <p className="font-semibold mb-2">{subject}</p>}
          <p className="whitespace-pre-wrap text-sm text-gray-800">{draft}</p>
        </div>
      )}

      {/* Resultat */}
      {result && (
        <div className="border rounded-2xl p-6 bg-white space-y-5">
          <div className="flex flex-wrap justify-between items-center gap-3">
            <div>
              <h3 className="font-semibold text-lg">Resultat – {result.action}</h3>
              {result.mode === 'mock' && (
                <p className="text-xs text-amber-600">
                  Demo-läge: automatiserat exempelsvar {result.variant + 1}
                </p>
              )}
            </div>
            <div className="flex gap-2">
              {result.mode === 'mock' && !loading && (
                <button
                  onClick={nextExample}
                  className="px-4 py-2 border rounded-lg text-sm hover:bg-gray-50"
                >
                  Nästa exempel ↻
                </button>
              )}
              {!loading && (
                <button
                  onClick={applyVersion}
                  className="px-4 py-2 bg-black text-white rounded-lg text-sm hover:bg-gray-800"
                >
                  Använd denna version
                </button>
              )}
            </div>
          </div>

          {parsed?.newVersion ? (
            <div className="space-y-4">
              <section>
                <p className="text-xs uppercase tracking-wide text-gray-400 mb-1">
                  Ny version
                </p>
                <div className="whitespace-pre-wrap text-sm bg-gray-50 rounded-xl p-4">
                  {parsed.newVersion}
                </div>
              </section>

              {parsed.explanation && (
                <section>
                  <p className="text-xs uppercase tracking-wide text-gray-400 mb-1">
                    Förklaring
                  </p>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">
                    {parsed.explanation}
                  </p>
                </section>
              )}

              {subjectSuggestions.length > 0 && (
                <section>
                  <p className="text-xs uppercase tracking-wide text-gray-400 mb-1">
                    Ämnesradsförslag (klicka för att använda)
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {subjectSuggestions.map((s) => (
                      <button
                        key={s}
                        onClick={() => setSubject(s)}
                        className="px-3 py-1.5 border rounded-full text-xs hover:bg-gray-50"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </section>
              )}

              {parsed.tips && (
                <section>
                  <p className="text-xs uppercase tracking-wide text-gray-400 mb-1">
                    Konfidens / Tips
                  </p>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">{parsed.tips}</p>
                </section>
              )}
            </div>
          ) : (
            <div className="whitespace-pre-wrap text-sm text-gray-800">{result.raw}</div>
          )}
        </div>
      )}

      {loading && !result?.raw && (
        <div className="text-center py-8 text-gray-500">Bearbetar med Email Studio…</div>
      )}
    </div>
  )
}
